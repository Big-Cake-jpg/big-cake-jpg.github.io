import{J as o,K as t,L as c,M as n}from"./framework.L05pX_B4.js";const r={};function s(_,a){const e=t("RouterView");return n(),c(e)}const f=o(r,[["render",s]]);export{f as default};
