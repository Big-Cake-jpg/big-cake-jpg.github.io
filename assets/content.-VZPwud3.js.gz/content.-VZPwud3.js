import{b as e}from"./framework.L05pX_B4.js";let n=[];function s(t){n.push(t),e(()=>{n=n.filter(o=>o!==t)})}const a=()=>n.forEach(t=>t()),d=a;export{s as o,d as r};
